
import 'package:foody/views/my_controller.dart';

class SliderController extends MyController {
  double labelSliderValue = 50;
  double tickSliderValue = 0;
  double dividerSliderValue = 50;

  DateTime yearValue = DateTime(2017, 01, 01);
  DateTime hourValue = DateTime(2020, 01, 01, 13, 00, 00);

  DateTime dateValue = DateTime(2016, 1, 01);
  double stepSliderValue = 0;
}
