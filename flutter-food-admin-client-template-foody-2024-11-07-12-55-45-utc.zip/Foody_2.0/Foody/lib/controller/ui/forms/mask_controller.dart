
import 'package:foody/views/my_controller.dart';

class MaskController extends MyController {}
