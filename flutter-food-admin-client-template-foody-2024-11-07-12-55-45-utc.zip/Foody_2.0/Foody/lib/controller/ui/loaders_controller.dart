
import 'package:foody/views/my_controller.dart';

class LoadersController extends MyController {}
