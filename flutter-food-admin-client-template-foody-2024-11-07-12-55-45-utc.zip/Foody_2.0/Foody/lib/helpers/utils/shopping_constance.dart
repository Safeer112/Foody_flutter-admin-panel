import 'package:foody/model/cart_model.dart';

class ShoppingCache {
  static List<CartData>? carts;

  static bool isFirstTime = true;
}
