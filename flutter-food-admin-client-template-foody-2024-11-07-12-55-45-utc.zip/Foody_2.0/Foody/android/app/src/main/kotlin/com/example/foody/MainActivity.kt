package com.example.foody

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
